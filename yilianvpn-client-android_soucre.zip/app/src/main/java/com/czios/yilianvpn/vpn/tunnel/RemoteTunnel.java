package com.czios.yilianvpn.vpn.tunnel;

import com.czios.yilianvpn.R;
import com.czios.yilianvpn.vpn.utils.ProxyConfig;
import com.czios.yilianvpn.vpn.service.MyVpnService;
import com.czios.yilianvpn.vpn.tcpip.IPHeader;
import com.czios.yilianvpn.vpn.utils.DebugLog;

import java.io.IOException;

import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;


public class RemoteTunnel implements Runnable {

    private static final String TAG = RemoteTunnel.class.getSimpleName();
    private MyVpnService myVpnService = null;
    private SocketChannel socketChannel = null;
    private boolean closed = false;
    private final byte[] cacheBytes = new byte[ProxyConfig.MUTE * 2];
    private int cacheBytesSize = 0;
    private Thread thread = null;
    private String ipAndPort;
    public static byte CTRL = (byte) 203;
    private int maxProxyNum = 0;
    private int tcpProxyNum = 0;
    private int udpProxyNum = 0;


    public RemoteTunnel(MyVpnService myVpnService) {
        this.myVpnService = myVpnService;
    }

    public void start() {
        connectServer();
        if(!closed){
            thread = new Thread(this, TAG);
            thread.start();
        }
    }

    public void connectServer() {
        ipAndPort = ProxyConfig.SERVER_IP + ":" + ProxyConfig.SERVER_PORT;
        DebugLog.iWithTag(TAG, "connecting server(%s).", ipAndPort);

        try {
            socketChannel = SocketChannel.open();
            socketChannel.configureBlocking(true);
            socketChannel.connect(new InetSocketAddress(ProxyConfig.SERVER_IP, ProxyConfig.SERVER_PORT));
            myVpnService.protect(socketChannel.socket());
            sendCtrlPacket((short) 1000, (short) 200);
            DebugLog.iWithTag(TAG, "connect server(%s) succeed.", ipAndPort);
        } catch (IOException e) {
            DebugLog.dWithTag(TAG, "connect server(%s) fail.", ipAndPort);
            close(myVpnService.getString(R.string.can_not_connect_server));
        }
    }

    public void sendCtrlPacket(short code, short state) {
        byte[] header = new byte[IPHeader.IP4_HEADER_SIZE];
        IPHeader ipheader = new IPHeader(header, 0);
        ipheader.setHeaderLength(IPHeader.IP4_HEADER_SIZE);
        ipheader.setTotalLength((short) IPHeader.IP4_HEADER_SIZE);
        ipheader.setSourceIP(ProxyConfig.USER_NAME);
        ipheader.setDestinationIP(ProxyConfig.USER_PWD);
        ipheader.setFlagsAndOffset(code);
        ipheader.setIdentification(state);
        ipheader.setProtocol(RemoteTunnel.CTRL);
        processPacket(header, 0, IPHeader.IP4_HEADER_SIZE);
    }

    //发送给服务器
    public void processPacket(byte[] bytes, int offset, int size) {
        try {
            socketChannel.write(ByteBuffer.wrap(bytes, offset, size));
        } catch (IOException e) {
            DebugLog.wWithTag(TAG, "Network write error: %s %s", ipAndPort, e);
            close(myVpnService.getString(R.string.send_packet_error));
        }
    }

    public void close(String errMsg) {
        if(closed) {
            System.out.println("close again, msg: " + errMsg);
            return;
        }
        closed = true;
        MyVpnService.errorMsg = errMsg;
        myVpnService.setVpnClosedStatus(true);
        if (thread != null)
            thread.interrupt();
        try {
            socketChannel.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public boolean isClose() {
        return closed;
    }

    public void processCTRLPacket(byte[] packet, int offset){
        IPHeader ipHeader = new IPHeader(packet, offset);
        maxProxyNum = ipHeader.getFlagsAndOffset();
        int code = ipHeader.getIdentification();
        if(code == 1000){
            int state = ipHeader.getSourceIP();
            switch (state) {
                case 200:
                    //String msg = vpnService.getString(R.string.user_verify_succeed);
                    break;
                case 400:
                    close(myVpnService.getString(R.string.server_close_client));
                    break;
                case 401:
                    close(myVpnService.getString(R.string.server_check_packet_error));
                    break;
                case 402:
                    close(myVpnService.getString(R.string.server_client_expire));
                    break;
                case 403:
                    close(myVpnService.getString(R.string.user_verify_fail));
                    break;
                case 404:
                    close(myVpnService.getString(R.string.server_on_max_client_connect));
                    break;
                default:
                    close(myVpnService.getString(R.string.server_connect_ctrl_packet_unknown_code) + "code:" + state);
                    break;
            }
        }else if(code == 1001){
            tcpProxyNum = ipHeader.getSourceIP();
            udpProxyNum = ipHeader.getDestinationIP();
        }
    }

    public void processRevPacket(byte[] packet, int offset, int size) {
        IPHeader ipHeader = new IPHeader(packet, offset);
        byte protocol = ipHeader.getProtocol();
        if (protocol == IPHeader.TCP) {
            myVpnService.write(packet, offset, size);
        } else if (protocol == IPHeader.UDP) {
            myVpnService.write(packet, offset, size);
        } else if (protocol == RemoteTunnel.CTRL) {
            processCTRLPacket(packet, offset);
        } else {
            DebugLog.dWithTag(TAG, "rev(%s) unknown protocol packet.", ipAndPort);
        }
    }

    public void processRevBuffer(byte[] bytes, int offset, int size) {
        if (cacheBytesSize > 0) {
            System.arraycopy(bytes, offset, cacheBytes, cacheBytesSize, size);
            size = cacheBytesSize + size;
            cacheBytesSize = 0;
            processRevBuffer(cacheBytes, 0, size);
            return;
        }
        if (size < IPHeader.IP4_HEADER_SIZE) {
            System.arraycopy(bytes, offset, cacheBytes, 0, size);
            cacheBytesSize = size;
            return;
        }

        IPHeader IpHeader = new IPHeader(bytes, offset);
        int totalLength = IpHeader.getTotalLength();
        if (totalLength <= 0 || totalLength > ProxyConfig.MUTE) {
            close(myVpnService.getString(R.string.rev_bad_length_packet));
            return;
        }
        if (totalLength < size) {
            processRevPacket(bytes, offset, totalLength);
            int nextDataSize = size - totalLength;
            processRevBuffer(bytes, (offset + totalLength), nextDataSize);
        } else if (totalLength == size) {
            processRevPacket(bytes, offset, size);
        } else {
            System.arraycopy(bytes, offset, cacheBytes, 0, size);
            cacheBytesSize = size;
        }
    }


    @Override
    public void run() {
        int size = 0;
        try {
            byte[] bytes = new byte[ProxyConfig.MUTE];
            while (size != -1 && socketChannel.isOpen() && !closed) {
                size = socketChannel.read(ByteBuffer.wrap(bytes));
                if (size > 0) {
                    processRevBuffer(bytes, 0, size);
                }
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            //e.printStackTrace();
            close(myVpnService.getString(R.string.connect_tunnel_error_closed));
            return;
        }
        close(myVpnService.getString(R.string.connect_server_do_close));
    }

    public int getMaxProxyNum(){
        return maxProxyNum;
    }

    public int getTcpProxyNum(){
        return tcpProxyNum;
    }

    public int getUdpProxyNum(){
        return udpProxyNum;
    }
}
