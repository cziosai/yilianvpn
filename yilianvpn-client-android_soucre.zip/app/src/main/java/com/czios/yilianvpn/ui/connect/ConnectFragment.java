package com.czios.yilianvpn.ui.connect;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.czios.yilianvpn.R;
import com.czios.yilianvpn.databinding.FragmentConnectBinding;
import com.czios.yilianvpn.ui.options.OptionsFragment;
import com.czios.yilianvpn.vpn.service.MyVpnService;
import com.czios.yilianvpn.vpn.utils.ProxyConfig;
import com.czios.yilianvpn.vpn.utils.VpnServiceHelper;

public class ConnectFragment extends Fragment {

    private FragmentConnectBinding binding;
    private View root;
    private final Handler handler = new Handler();

    private TextView infoMsg;
    private TextView errorMsg;
    private Button startRun;
    private Button stopRun;
    private static boolean isRunning = false;
    private static boolean onStart = false;
    private static boolean onStop = false;
    ProxyConfig.VpnStatusListener vpnStatusListener = new ProxyConfig.VpnStatusListener() {
        @Override
        public void onVpnStart(Context context) {
            handler.post(() -> {
                        isRunning = true;
                        onStart = false;
                        onStop = false;
                        updateUI();
                        System.out.println("vpn start");
                    }
            );
        }

        @Override
        public void onVpnEnd(Context context) {
            handler.post(() -> {
                        isRunning = false;
                        onStart = false;
                        onStop = false;
                        updateUI();
                        System.out.println("vpn stop");
                    }
            );
        }
    };

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentConnectBinding.inflate(inflater, container, false);
        root = binding.getRoot();
        Context ctx = root.getContext();

        infoMsg = binding.infoMsg;
        errorMsg = binding.errorMsg;
        startRun = binding.startRun;
        stopRun = binding.stopRun;

        OptionsFragment.readOptins(ctx);

        startRun.setOnClickListener(view -> {
            MyVpnService.errorMsg = "";
            MyVpnService.closeByUser = false;
            if(!isRunning && !onStart){
                if(OptionsFragment.getPreferenceValue(ctx, "new-install").equals("0")){
                    OptionsFragment.writeToPreference(ctx, "new-install", "no");
                    startVPN();
                    closeVpn();
                    MyVpnService.errorMsg = getString(R.string.please_reconnect);
                }else{
                    onStart = true;
                    startVPN();
                }
                updateUI();
            }
        });
        stopRun.setOnClickListener(view -> {
            MyVpnService.closeByUser = true;
            if(isRunning && !onStop){
                onStop = true;
                closeVpn();
                updateUI();
            }
        });
        ProxyConfig.Instance.cleanVpnStatusListener();
        ProxyConfig.Instance.registerVpnStatusListener(vpnStatusListener);
        updateUI();
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @SuppressLint("DefaultLocale")
    private void updateUI() {
        if(onStart){
            startRun.setVisibility(View.VISIBLE);
            stopRun.setVisibility(View.INVISIBLE);
            infoMsg.setText(getString(R.string.connecting));
        }else if(onStop){
            startRun.setVisibility(View.INVISIBLE);
            stopRun.setVisibility(View.VISIBLE);
            infoMsg.setText(getString(R.string.disconnecting));
        }else if (VpnServiceHelper.vpnRunningStatus()){
            startRun.setVisibility(View.INVISIBLE);
            stopRun.setVisibility(View.VISIBLE);
            infoMsg.setText(String.format("%s%s:%d", getString(R.string.connected), ProxyConfig.SERVER_IP, ProxyConfig.SERVER_PORT));
        }else if(!VpnServiceHelper.vpnRunningStatus()){
            startRun.setVisibility(View.VISIBLE);
            stopRun.setVisibility(View.INVISIBLE);
            infoMsg.setText(String.format("%s%s:%d", getString(R.string.not_connect), ProxyConfig.SERVER_IP, ProxyConfig.SERVER_PORT));
        }
        String msg = "";
        String error = MyVpnService.errorMsg;
        if (MyVpnService.errorMsg.length() > 0 && !MyVpnService.closeByUser) {
            msg = getString(R.string.error_msg) + error;
        }
        errorMsg.setText(msg);
    }

    private void startVPN() {
        if (!VpnServiceHelper.vpnRunningStatus()) {
            VpnServiceHelper.changeVpnRunningStatus(this.getContext(), true);
        }
    }

    private void closeVpn() {
        if (VpnServiceHelper.vpnRunningStatus()) {
            VpnServiceHelper.changeVpnRunningStatus(this.getContext(), false);
        }
    }
}